function init() {
    $("#oldPwd").focus();
    $(".alert").delay(2666).slideUp();
}

$(function () {
    init();
});