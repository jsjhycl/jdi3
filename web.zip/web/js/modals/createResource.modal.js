//新建布局资源模态框
function CreateResource() {
    this.$createResource = $("#create_resource_modal")
    this.$resoureRelId = this.$createResource.find('[name="model_resource_relId"]')
    this.data = []
    this.$resoureName = this.$createResource.find('[name="model_resource_name"]')
    this._fillRelId = function () {
        var that = this,
            value = that.$createResource.find('[name="model_resource_subCategory"]:checked').val(),
            defaultOption = {
                name: "请选择关联表单",
                value: ""
            },
            options = that.data.filter(function (fitem) {
                return value === fitem.basicInfo.subCategory;
            }).map(function (mitem) {
                return {
                    name: mitem.name,
                    value: mitem.customId
                }
            });
        Common.fillSelect(that.$resoureRelId, defaultOption, options, null, false);
    }
}
CreateResource.prototype = {
    initData: function () {
        var that = this;
        var parms = {
            type:0,
            isAll:true,
        }
        new NewService().list(parms ,function(result){
            Common.handleResult(result,function(data){
                if(!Array.isArray(data.data))return;
                console.log(data)
                that.data = data.data;
                that._fillRelId()
            })
        })
        // new ProductService().list("表单", 20, function (result) {
        //     Common.handleResult(result, function (data) {
        //         if (!Array.isArray(data)) return;
        //         that.data = data.slice(0);
        //         that._fillRelId();
        //     });
        // });
    },
    bindEvents: function () {
        var that = this;
        //切换资源分类
        that.$createResource.on("click", '[name="model_resource_subCategory"]', function () {
            that._fillRelId();
        })
        //选择关联表单事件
        that.$createResource.on("change", '[name="model_resource_relId"]', function () {
            var value = $(this).val();
            if (value) {
                var text = $(this).find("option:selected").text();
                that.$resoureName.val(text);
            } else {
                that.$resoureName.val("");
            }
        });
        //保存资源
        that.$createResource.find(".modal-footer .save").click(function () {
            var name = that.$resoureName.val();
            if (!name) return alert("布局名称不能为空！");
            var relid = that.$resoureRelId.val();
            if (!relid) return alert("关联表单不可以为空！");
            var data = {
                relid: relid,
                name: name,
                type: "布局"
            };
            var subCategory = "";
            that.data.forEach(function(item){
                if(item.customId==relid){
                    subCategory = item;
                }
            })
            console.log(relid)
            new Workspace().load(relid, name, "表单", null, null, subCategory)
            that.$createResource.modal("hide");
            // new ResourceService().add(data, function (result) {
            //     var resId = result.result;
            //     Common.handleResult(result, function () {
            //         new ProductService().detail(data.relid, function (presult) {
            //             Common.handleResult(presult, function (pdata) {
            //                 if (pdata) {
            //                     new Workspace().load(resId, data.name, "布局", null, null, pdata)
            //                 }
            //             })
            //         })
            //         that.$createResource.modal("hide");
            //     })
            // })
            new Main().open();
        })
    }
}